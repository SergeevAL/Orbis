-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 20 2018 г., 19:26
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `f90065eh_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `impressions`
--
-- Создание: Сен 19 2018 г., 14:25
-- Последнее обновление: Сен 20 2018 г., 10:27
--

DROP TABLE IF EXISTS `impressions`;
CREATE TABLE `impressions` (
  `impression_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `impressions`
--

INSERT INTO `impressions` (`impression_id`, `user_id`, `datetime`) VALUES
(1, 1, '2018-09-19 19:36:58'),
(2, 2, '2018-09-19 19:36:58'),
(3, 2, '2018-09-19 19:37:18'),
(4, 2, '2018-09-19 19:37:26'),
(5, 3, '2018-09-19 19:37:36'),
(6, 3, '2018-09-19 23:00:12'),
(7, 2, '2018-09-19 23:00:17'),
(8, 3, '2018-09-19 23:00:22'),
(9, 5, '2018-09-20 10:27:37');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `impressions`
--
ALTER TABLE `impressions`
  ADD PRIMARY KEY (`impression_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `impressions`
--
ALTER TABLE `impressions`
  MODIFY `impression_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
